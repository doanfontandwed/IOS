//
//  ViewController2.swift
//  doan
//
//  Created by Tran Dang on 5/26/22.
//  Copyright © 2022 Tran Dang. All rights reserved.
//

import UIKit

class ViewController2: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    
    var cartProductArray:[Product] = []
    var subTotal: Int = 0
    @IBOutlet weak var cartTableView: UITableView!
    
    @IBOutlet weak var subTotalLabel: UILabel!
    @IBOutlet weak var totalPaymentLabel: UILabel!
    
    @IBAction func confirmOrderButton(_ sender: UIButton) {
        let alert = UIAlertController(title: "Xác nhận đơn hàng", message: "Bạn chắc chắn ?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: {action in self.performSegue(withIdentifier: "moveVC3", sender: self)}))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: {action in print ("Canceled")}))
        
        //wolfTurnLabel.text = "GAME OVER!"
       
        present(alert, animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cartTableView.delegate = self
        cartTableView.dataSource = self
        title = "Thanh Toán"
        
        subTotal = cartProductArray.map{$0.productPrice *  $0.productCount}.reduce(0, +)
        subTotalLabel.text = " \(subTotal)"
        totalPaymentLabel.text = " \(subTotal + (subTotal*10/100))"

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cartProductArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "CartTableViewCell", for: indexPath) as? CartTableViewCell{
            cell.menuLabel.text = cartProductArray[indexPath.row].productName
            cell.quantityLabel.text = "\(cartProductArray[indexPath.row].productCount) pcs"
            cell.priceLabel.text = " \(cartProductArray[indexPath.row].productPrice * cartProductArray[indexPath.row].productCount )"
            return cell
        }
        return UITableViewCell()
    }
}
    

    
